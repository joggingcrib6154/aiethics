import React from 'react';
import html2canvas from 'html2canvas';

export default function MaskGrid({ choices }) {
  const tileSize = 96;
  const totalTiles = 20;

  const fragments = Array.from({ length: totalTiles }, (_, i) => {
    const choice = choices[i]?.index;
    if (choice !== undefined && [0, 1, 2].includes(choice)) {
      const questionNum = i + 1;
      const letter = ['a', 'b', 'c'][choice];
      return `${questionNum}${letter}.png`;
    }
    return null;
  });

  return (
    <div
      className="mask-grid"
      style={{
        position: 'fixed',
        top: 24,
        right: 24,
        transform: 'scale(0.5)',
        transformOrigin: 'top right',
        zIndex: 1000,
        display: 'grid',
        gridTemplateColumns: `repeat(4, ${tileSize}px)`,
        gridTemplateRows: `repeat(5, ${tileSize}px)`
      }}
    >
      {fragments.map((filename, i) => (
        <div
          key={`${i}-${filename ?? 'empty'}`}
          style={{
            width: `${tileSize}px`,
            height: `${tileSize}px`,
            boxSizing: 'border-box',
            border: '1px solid #374151',
            backgroundColor: '#111827',
            borderRadius: '12px',
            overflow: 'hidden',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}
        >
          {filename ? (
            <img
              src={`/maskfrags/${filename}`}
              alt=""
              style={{
                width: '100%',
                height: '100%',
                objectFit: 'cover',
                animation: 'fadeInScale 0.5s ease'
              }}
            />
          ) : (
            <div
              style={{
                width: '100%',
                height: '100%',
                backgroundColor: '#1f2937',
                color: '#4b5563',
                fontSize: '1.5rem',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}
            >
              •
            </div>
          )}
        </div>
      ))}

      <style>
        {`
          @keyframes fadeInScale {
            from {
              opacity: 0;
              transform: scale(0.5);
            }
            to {
              opacity: 1;
              transform: scale(1);
            }
          }
        `}
      </style>
    </div>
  );
}

export async function downloadMaskGrid(choices) {
  try {
    const cols = 4;
    const rows = 5;
    const tile = 96;
    const W = cols * tile;
    const H = rows * tile;

    if (!choices || !Array.isArray(choices)) {
      console.error('downloadMaskGrid: invalid choices');
      return;
    }

    // Helper: load image
    const loadImage = (src) => new Promise((resolve, reject) => {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => resolve(img);
      img.onerror = reject;
      img.src = src;
    });

    // Helper: compute tight alpha bbox (ignores fully transparent borders)
    const alphaBBox = (img) => {
      const w = img.naturalWidth || img.width;
      const h = img.naturalHeight || img.height;
      const c = document.createElement('canvas');
      c.width = w; c.height = h;
      const x = c.getContext('2d');
      x.drawImage(img, 0, 0);
      const data = x.getImageData(0, 0, w, h).data;
      let minX = w, minY = h, maxX = 0, maxY = 0;
      const thr = 8; // alpha threshold
      for (let y = 0; y < h; y++) {
        for (let i = 0; i < w; i++) {
          const k = (y * w + i) * 4 + 3; // alpha index
          if (data[k] > thr) {
            if (i < minX) minX = i;
            if (i > maxX) maxX = i;
            if (y < minY) minY = y;
            if (y > maxY) maxY = y;
          }
        }
      }
      if (maxX <= minX || maxY <= minY) {
        return { sx: 0, sy: 0, sw: w, sh: h };
      }
      // Add a tiny padding so edges don't get clipped when scaled
      const pad = 2;
      minX = Math.max(0, minX - pad);
      minY = Math.max(0, minY - pad);
      maxX = Math.min(w - 1, maxX + pad);
      maxY = Math.min(h - 1, maxY + pad);
      return { sx: minX, sy: minY, sw: maxX - minX + 1, sh: maxY - minY + 1 };
    };

    // Build export canvas @2x for crispness
    const scale = 2;
    const out = document.createElement('canvas');
    out.width = W * scale;
    out.height = H * scale;
    const ctx = out.getContext('2d', { alpha: false });
    ctx.scale(window.devicePixelRatio || 1, window.devicePixelRatio || 1);
    ctx.scale(scale, scale);

    // Background to match UI
    ctx.fillStyle = '#111827';
    ctx.fillRect(0, 0, W, H);

    // Load and draw tiles
    const loaders = [];
    for (let i = 0; i < rows * cols; i++) {
      const v = choices[i];
      const idx = typeof v === 'number' ? v : v?.index;
      if (idx === 0 || idx === 1 || idx === 2) {
        const q = i + 1;
        const letter = ['a','b','c'][idx];
        const src = `/maskfrags/${q}${letter}.png`;
        loaders.push({ i, p: loadImage(src) });
      }
    }

    const images = await Promise.all(loaders.map(async o => ({ i: o.i, img: await o.p })));

    images.forEach(({ i, img }) => {
      const col = i % cols;
      const row = Math.floor(i / cols);
      const dx = col * tile;
      const dy = row * tile;

      const { sx, sy, sw, sh } = alphaBBox(img);

      // Draw on offscreen white-backed canvas to neutralize transparency darkness
      const temp = document.createElement('canvas');
      temp.width = sw;
      temp.height = sh;
      const tctx = temp.getContext('2d', { alpha: false });
      tctx.fillStyle = '#ffffff';
      tctx.fillRect(0, 0, sw, sh);
      tctx.drawImage(img, sx, sy, sw, sh, 0, 0, sw, sh);
      ctx.drawImage(temp, 0, 0, sw, sh, dx, dy, tile, tile);
    });

    // Download
    out.toBlob((blob) => {
      if (!blob) return;
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'final_mask.png';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }, 'image/png');
  } catch (e) {
    console.error('downloadMaskGrid failed:', e);
  }
}